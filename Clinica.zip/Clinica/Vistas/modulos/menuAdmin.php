<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
    
      <ul class="sidebar-menu">
        
        <li>
          <a href="http://localhost/clinica/inicio">
            <i class="fa fa-home"></i>
            <span>Inicio</span>
          </a>
        </li>

        <li>
          <a href="http://localhost/clinica/secretarias">
            <i class="fa fa-female"></i>
            <span>Secretarias</span>
          </a>
        </li>

        <li>
          <a href="http://localhost/clinica/doctores">
            <i class="fa fa-user-md"></i>
            <span>Doctores</span>
          </a>
        </li>

        <li>
          <a href="http://localhost/clinica/consultorios">
            <i class="fa fa-medkit"></i>
            <span>Consultorios</span>
          </a>
        </li>

        <li>
          <a href="http://localhost/clinica/pacientes">
            <i class="fa fa-users"></i>
            <span>Pacientes</span>
          </a>
        </li>

      </ul>

    </section>
    <!-- /.sidebar -->
  </aside>